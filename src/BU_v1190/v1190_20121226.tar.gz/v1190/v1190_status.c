/* v1190_status.c ---- show V1190 status                                   */
/*								           */
/*  Version 1.00        2012-12-24      by A. Tamii (For Linux2.6)GE-FANUC */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <vme/vme.h>
#include <vme/vme_api.h>

#include "v1190.h"

int main(int argc, char *argv[]){
  int ret;
  unsigned short cr;
  unsigned short sr;
  int module_number = 0;
  V1190_p v1190=(V1190_p)NULL;

  if(argc>1 && !strcmp(argv[1],"-h")){
    fprintf(stderr, "%s ... show v1190 status.\n", argv[0]);
    fprintf(stderr, "Usage: %s [module_number]\n", argv[0]);
    fprintf(stderr, " module_number: the default is 0.\n");
    exit(0);
  }

  if(argc>1){
    module_number = atoi(argv[1]);
  }

  /* ------------- Open ------------ */

  fprintf(stderr, "V1190A base address = 0x%.8x\n", V1190_BASE(module_number));

  fprintf(stderr, "open V1190A\n");
  ret = v1190_open();
  if(ret!=0){
    fprintf(stderr, "Error in v1190_open()\n");
    exit(-1);
  }

  fprintf(stderr, "map V1190A(module_number=%d)\n", module_number);
  v1190 = v1190_map(module_number);
  if(v1190==(V1190_p)NULL){
    fprintf(stderr, "Error in v1190_map()\n");
    v1190_close();
    exit(-1);
  }

  fprintf(stderr, "v1190 = 0x%.8lx\n", (long)v1190);

  /* ------------- Show status ------------ */
  printf("--------------------------------------------------\n");

  cr = v1190->control_register;
  printf("control register = 0x%.4x\n", cr);

  printf("  BERR EN  : Bus Error Enable      : %s\n", 
    (cr&0x8000)==0 ? "0...Disabled" : "1...Enabled");
  printf("  TERM     : Software Termination  : %s\n", 
    (cr&0x4000)==0 ? "0...OFF" : "1...ON");

  sr = v1190->status_register;
  printf("status register = 0x%.4x\n", sr);
  printf("  TRG MATCH: operating mode        : %s\n", 
     (sr&0x0008)==0 ? "0...continuous" : "1...trigger matching");

  printf("--------------------------------------------------\n");

  /* ------------- Close ------------ */
  fprintf(stderr, "unmap V1190A\n");
  ret = v1190_unmap(module_number);
  if(ret!=0){
    fprintf(stderr, "Error in v1190_unmap()\n");
  }

  fprintf(stderr, "close V1190A\n");
  ret = v1190_close();
  if(ret!=0){
    fprintf(stderr, "Error in v1190_close()\n");
    exit(-1);
  }

  return 0; 
}


