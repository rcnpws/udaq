/* v1190test.c ---- access test to V1190A                                  */
/*								           */
/*  Version 1.00        2012-12-23      by A. Tamii (For Linux2.6)GE-FANUC */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <vme/vme.h>
#include <vme/vme_api.h>

#include "v1190.h"

vme_bus_handle_t bus_handle;
vme_master_handle_t window_handle;

unsigned char *v1190;

/* 
  if error NULL pointer is retured. 
*/
unsigned char *v1190Open(void)
{
  unsigned char *ptr;

  if(vme_init(&bus_handle)){
    perror("v1190Open: Error initializing the VMEbus");
    return NULL;
  }

  if(vme_master_window_create(bus_handle, &window_handle, 
       V1190_BASE, V1190_MODE, V1190_SIZE, 0, NULL)){
    perror("v1190Open: Error creating the window");
    vme_term(bus_handle);
    return NULL;
  }

  ptr = (unsigned char *)vme_master_window_map(bus_handle, window_handle, 0);
  if(ptr==(unsigned char*)NULL){
    perror("v1190Open: Error mapping the window");
    vme_master_window_release(bus_handle, window_handle);
    vme_term(bus_handle);
    return NULL;
  }
  return ptr;
}

/* 
  return code
    0 success
   -1 error
*/
int v1190Close(){
  if(vme_master_window_unmap(bus_handle, window_handle)){
    perror("v1190Close: Error unmapping the window");
    vme_master_window_release(bus_handle, window_handle);
    vme_term(bus_handle);
    return -1;
  }

  if(vme_master_window_release(bus_handle, window_handle)){
    perror("v1190Close: Error releasing the window");
    vme_term(bus_handle);
    return -1;
  }

  if(vme_term(bus_handle)){
    perror("v1190Close: Error terminating");
    return -1;
  }

  return 0;
}

/* 
  return code
    0 success
   -1 error
*/
int MicroHandshakeWrite(unsigned short opecode){
  unsigned short *micro_handshake_register;
  unsigned short *micro_register;
  micro_register = (unsigned short*)&v1190[V1190_MicroRegister];
  micro_handshake_register = (unsigned short*)&v1190[V1190_MicroHandshake];

  if((*micro_handshake_register & V1190_MicroHandshakeRegister_WriteOK)==0){
    fprintf(stderr, "MicorHandshakeWrite: WriteOK bit of the Micro Handshake Register is 0.\n");
    return -1;
  }
  *micro_register = opecode;
  return 0;
}

int main(){
  int ret;
  unsigned short svalue;

  fprintf(stderr, "open V1190A\n");
  v1190 = v1190Open();
  if(v1190==(unsigned char*)NULL){
    fprintf(stderr, "Error in v1190Open()\n");
    exit(-1);
  }
  
  printf("v1190 = 0x%.8lx\n", (long)v1190);

//--------------
  
//  MicroHandshakeWrite(V1190_OPECODE_TRIG_MATCH);
  MicroHandshakeWrite(V1190_OPECODE_CONTINUOUS_STORAGE);

  usleep(1000000);

//--------------

  svalue = *(unsigned short*)&v1190[V1190_CR];
  printf("control register = 0x%.4x\n", svalue);

  printf("  BERR EN: Bus Error Enable: %s\n", (svalue&0x8000)==0 ? "0...Disabled" : "1...Enabled");
  printf("  TERM: Software Termination: %s\n", (svalue&0x4000)==0 ? "0...OFF" : "1...ON");

  svalue = *(unsigned short*)&v1190[V1190_SR];
  printf("status register = 0x%.4x\n", *(unsigned short*)&v1190[V1190_SR]);
  printf("  TRG MATCH: operating mode: %s\n", 
     (svalue&0x0008)==0 ? "0...continuous" : "1...trigger matching");

  fprintf(stderr, "close V1190A\n");
  ret = v1190Close();
  if(ret!=0){
    fprintf(stderr, "Error in v1190Close()\n");
    exit(-1);
  }
  return 0; 
}


