#ifndef V1190_REG_H
#define V1190_REG_H

/*
 * Definitions for V1190
 *
 * Version 0.10  23-DEC-2012  by A. Tamii
 */


/* Size of I/O space */

#define V1190_BASE   0xEE000000         /* VME base address    */
#define V1190_SIZE   0x1206

/* VME addressing mode */
#if 0
#define V1190_MODE  VME_A32SD            /* 32bit Extended Prvileged Data Accesss  */
#else
#define V1190_MODE  VME_A32UD            /* 32bit Extended Non-Prvileged Data Accesss  */
#endif

/*
 * V1190 Memory Register
 */
#define V1190_CR        0x1000   /* control register */
#define V1190_SR        0x1002   /* status register */

#define V1190_MicroRegister  0x102E   /* micro register */
#define V1190_MicroHandshake 0x1030   /* micro handshake */


#define V1190_MicroHandshakeRegister_WriteOK 0x0001 /* micro handshake register write OK */


/*
 * V1190 microcode Opecode, see page 47 of the V1190 manual
 */
#define V1190_OPECODE_TRIG_MATCH          0x0000
#define V1190_OPECODE_CONTINUOUS_STORAGE  0x0100

#endif  /* for ifndef V1190_REG_H */
