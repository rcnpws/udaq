#ifndef VMEDAQ_REG_H
#define VMEDAQ_REG_H

/*
 * Definitions for VMEDAQ
 *
 * Version 0.10  03-NOV-2014  by A. Tamii
 */

#define VMEDAQ_HEADER_ID (0x44454D56)   // 'VMED'
#define VMEDAQ_TYPE_V1190                1
#define VMEDAQ_TYPE_V830                 2
#define VMEDAQ_TYPE_COUNTER_OFFSET       3

typedef struct VMEDAQ_HEADER {
  unsigned long id;
  unsigned long type;
  unsigned long counter;
  unsigned long sizeInBytes;
} VMEDAQ_HEADER_t, *VMEDAQ_HEADER_p;

/*
 * prototype definitions of library functions
 */

#endif  /* for ifndef VMEDAQ_REG_H */
