/* madc32_status.c ---- show MADC32 status                                 */
/*								           */
/*  Version 1.00        2016-03-08      by A. Tamii (For Linux2.6)GE-FANUC */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <vme/vme.h>
#include <vme/vme_api.h>

#include "madc32.h"

int main(int argc, char *argv[]){
  int ret;
  int module_number = 0;
  MADC32_p madc32=(MADC32_p)NULL;

  if(argc>1 && !strcmp(argv[1],"-h")){
    fprintf(stderr, "%s ... show madc32 status.\n", argv[0]);
    fprintf(stderr, "Usage: %s [module_number]\n", argv[0]);
    fprintf(stderr, " module_number: the default is 0.\n");
    exit(0);
  }

  if(argc>1){
    module_number = atoi(argv[1]);
  }

  /* ------------- Open ------------ */

  fprintf(stderr, "MADC32 base address = 0x%.8x\n", MADC32_BASE(module_number));

  fprintf(stderr, "open MADC32\n");
  ret = madc32_open();
  if(ret!=0){
    fprintf(stderr, "Error in madc32_open()\n");
    exit(-1);
  }

  fprintf(stderr, "map MADC32(module_number=%d)\n", module_number);
  madc32 = madc32_map(module_number);
  if(madc32==(MADC32_p)NULL){
    fprintf(stderr, "Error in madc32_map()\n");
    madc32_close();
    exit(-1);
  }

  fprintf(stderr, "madc32 = 0x%.8lx\n", (long)madc32);

  /* ------------- Show status ------------ */
  printf("--------------------------------------------------------------------------\n");

  int rev;
  rev = madc32->firmware_revision;
  printf("firmware revision = 0x%.4x [0x%.4lx]\n", rev, (long)&madc32->firmware_revision - (long)madc32);

  printf("--------------------------------------------------------------------------\n");


  /* ------------- Close ------------ */
  fprintf(stderr, "unmap MADC32\n");
  ret = madc32_unmap(module_number);
  if(ret!=0){
    fprintf(stderr, "Error in madc32_unmap()\n");
  }

  fprintf(stderr, "close MADC32\n");
  ret = madc32_close();
  if(ret!=0){
    fprintf(stderr, "Error in madc32_close()\n");
    exit(-1);
  }

  return 0; 
}


