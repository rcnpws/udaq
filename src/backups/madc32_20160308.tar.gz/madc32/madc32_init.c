/* madc32_init.c ---- init MADC32                                          */
/*								           */
/*  Version 1.00        2016-03-08      by A. Tamii (For Linux2.6)GE-FANUC */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <vme/vme.h>
#include <vme/vme_api.h>

#include "madc32.h"

int main(int argc, char *argv[]){
  int ret;
  int module_number = 0;


  /* default values */
  int irq_threshold = MADC_IRQ_THRESHOLD_DEFAULT;
  int multi_event = MADC32_MULTI_EVENT_YES_UNLIMITED;
  int marking_type = MADC32_MARKING_TYPE_EVENT_COUNTER;
  int adc_resolution = MADC32_ADC_RESOLUTION_4K_HIGH_RES;          /*  3.2 micro sec */

  MADC32_p madc32=(MADC32_p)NULL;

  if(argc>1 && !strcmp(argv[1],"-h")){
    fprintf(stderr, "%s ... init MADC32.\n", argv[0]);
    fprintf(stderr, "Usage: %s [module_number]\n", argv[0]);
    fprintf(stderr, " module_number: the default is 0.\n");
    fprintf(stderr, " -hd0 delay0   0=25ns, 1=150ns, 2=200ns, n=100+50*n\n");
    fprintf(stderr, " -hd1 delay1   0=25ns, 1=150ns, 2=200ns, n=100+50*n\n");
    fprintf(stderr, " -hw0 width0   50nsec * width0\n");
    fprintf(stderr, " -hw1 width1   50nsec * width1\n");
    fprintf(stderr, " -gg  gg_sel   0=not connected, 1=GG0, 2=GG1 3=GG0&GG1\n");
    exit(0);
  }

  int delay0 = 20;  /* default = 20 = 1100 nsec */
  int delay0 = 20;  /* default = 20 = 1100 nsec */


  if(argc>1){
    module_number = atoi(argv[1]);
  }

  /* ------------- Open ------------ */

  fprintf(stderr, "MADC32 base address = 0x%.8x\n", MADC32_BASE(module_number));

  fprintf(stderr, "open MADC32\n");
  ret = madc32_open();
  if(ret!=0){
    fprintf(stderr, "Error in madc32_open()\n");
    exit(-1);
  }

  fprintf(stderr, "map MADC32(module_number=%d)\n", module_number);
  madc32 = madc32_map(module_number);
  if(madc32==(MADC32_p)NULL){
    fprintf(stderr, "Error in madc32_map()\n");
    madc32_close();
    exit(-1);
  }

  fprintf(stderr, "madc32 = 0x%.8lx\n", (long)madc32);

  /* ------------- initialize MADC32  ------------ */
  madc32->multi_event = multi_event;
  madc32->irq_threshold = irq_threshold;
  madc32->marking_type = marking_type;  
  madc32->module_id = module_number;
  madc32->data_len_format = MADC32_DATA_LEN_FORMAT_32BIT;
  madc32->bank_operation = MADC32_BANK_OPERATION_BANKS_CONNECTED;
  madc32->adc_resolution = adc_resolution;

  printf("--------------------------------------------------------------------------\n");

  int rev;
  rev = madc32->firmware_revision;
  printf("firmware revision = 0x%.4x [0x%.4lx]\n", rev, (long)&madc32->firmware_revision - (long)madc32);

  printf("--------------------------------------------------------------------------\n");


  /* ------------- Close ------------ */
  fprintf(stderr, "unmap MADC32\n");
  ret = madc32_unmap(module_number);
  if(ret!=0){
    fprintf(stderr, "Error in madc32_unmap()\n");
  }

  fprintf(stderr, "close MADC32\n");
  ret = madc32_close();
  if(ret!=0){
    fprintf(stderr, "Error in madc32_close()\n");
    exit(-1);
  }

  return 0; 
}


